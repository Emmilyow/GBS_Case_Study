package com.empSystem.CS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmploymentManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
